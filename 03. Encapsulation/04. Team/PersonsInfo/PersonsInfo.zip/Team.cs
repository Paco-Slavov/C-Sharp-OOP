﻿using System.Security.Cryptography.X509Certificates;

namespace PersonsInfo
{
    public class Team
    {
        private string name;
        private List<Person> players;
        private List<Person> reserves;

        public Team(string name)
        {
            this.name = name;
            this.players = new();
            this.players = new();
        }
        public IReadOnlyCollection<Person> Players
            => this.players.AsReadOnly();

        public IReadOnlyCollection<Person> Reserves
            => this.reserves.AsReadOnly();

        public void AddPlayer(Person person)
        {
            if (person.Age < 40)
            {
                this.players.Add(person);
            }
            else
            {
                this.reserves.Add(person);
            }
        }
    }
}
