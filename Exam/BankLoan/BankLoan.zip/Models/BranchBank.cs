﻿namespace BankLoan.Models
{
    public class BranchBank : Bank
    {
        public BranchBank(string name) : base(name, 25)
        {

        }
    }
}
