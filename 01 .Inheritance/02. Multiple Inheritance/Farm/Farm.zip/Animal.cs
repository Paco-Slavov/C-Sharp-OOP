﻿namespace Farm
{
    public class Animal
    {
        Animal animal = new();

        public void Eat()
        {
            Console.WriteLine("eating...");
        }
    }
}
