﻿namespace Farm
{
    public class Puppy : Dog
    {
        Puppy puppy = new();

        public void Weep()
        {
            Console.WriteLine("weeping...");
        }
    }
}
