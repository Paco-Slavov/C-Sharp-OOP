﻿namespace Farm
{
    public class Dog : Animal
    {
        Dog dog = new();

        public void Bark()
        {
            Console.WriteLine("barkiing...");
        }
    }
}
