﻿using WildFarm.Models.Interfaces;

namespace WildFarm.Models.Foods;

public class Meat : Food
{
    //Constructor
    public Meat(int quantity) : base(quantity) { }
}