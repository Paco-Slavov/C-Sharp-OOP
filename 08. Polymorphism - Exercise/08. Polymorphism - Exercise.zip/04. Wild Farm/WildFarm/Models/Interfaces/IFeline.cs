﻿namespace WildFarm.Models.Interfaces;

public interface IFeline : IAnimal
{
    //Properties
    public string Breed { get; }
}
