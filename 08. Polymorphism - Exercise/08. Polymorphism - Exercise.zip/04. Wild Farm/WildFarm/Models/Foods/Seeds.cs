﻿using WildFarm.Models.Interfaces;

namespace WildFarm.Models.Foods;

public class Seeds : Food
{
    //Constructor
    public Seeds(int quantity) : base(quantity) { }
}