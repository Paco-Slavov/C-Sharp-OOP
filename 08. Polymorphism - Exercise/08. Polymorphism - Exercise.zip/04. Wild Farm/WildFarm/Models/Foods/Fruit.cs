﻿using WildFarm.Models.Interfaces;

namespace WildFarm.Models.Foods;

public class Fruit : Food
{
    //Constructor
    public Fruit(int quantity) : base(quantity) { }
}