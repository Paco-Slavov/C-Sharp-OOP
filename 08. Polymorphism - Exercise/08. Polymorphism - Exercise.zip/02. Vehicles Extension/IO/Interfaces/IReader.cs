﻿namespace VehiclesExtension.IO.Interfaces;

public interface IReader
{
    string ReadLine();
}