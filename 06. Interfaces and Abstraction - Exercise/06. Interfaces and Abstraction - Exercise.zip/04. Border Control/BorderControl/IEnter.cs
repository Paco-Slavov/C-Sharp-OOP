﻿namespace BorderControl
{
    public interface IEnter
    {
        public string Id { get; }
    }
}
