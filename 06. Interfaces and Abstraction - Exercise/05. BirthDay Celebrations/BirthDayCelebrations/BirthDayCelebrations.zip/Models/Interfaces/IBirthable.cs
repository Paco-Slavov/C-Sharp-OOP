﻿namespace BirthDayCelebrations.Models.Interfaces;

public interface IBirthable
{
    public string Name { get; }
    public string Birthdate { get; }
}
