﻿namespace Telephony;

public interface IPhone
{
    void Call(string number);
}
