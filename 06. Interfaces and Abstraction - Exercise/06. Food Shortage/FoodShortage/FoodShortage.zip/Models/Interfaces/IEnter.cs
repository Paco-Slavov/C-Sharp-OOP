﻿namespace FoodShortage.Models.Interfaces;

public interface IEnter
{
    public string Id { get; }
}